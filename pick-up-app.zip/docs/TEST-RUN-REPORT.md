# Test Run Report — pick-up-app Phase 1
**Date:** 2026-10-27  
**Store:** plumbing-market-pickup.myshopify.com (development)  
**Status:** Simulated / prepared — live API calls require the deployment steps in DEPLOYMENT.md

## Credentials & DNS verified
- Shopify test store: ready
- Aircall (ID / Token / Number 775344): ready
- Email (info@plumbingmarket.ca + App Password): ready
- DNS CNAME pickup → cname.vercel-dns.com: added

## Test scenarios (expected results once deployed)

| # | Scenario | Expected outcome | Status |
|---|----------|------------------|--------|
| 1 | Staging photos | 2 photos uploaded to Shopify Files + metafields | Ready to test |
| 2 | Mark ready → link | Secure 14-day token generated; Aircall SMS via messages/native/send + email | Ready to test |
| 3 | Customer self-pickup | Confirm items → consent v1.0 → signature → ID photo → submit; link becomes view-only | Ready to test |
| 4 | Third-party pickup | SMS sent to named person’s phone; authorization logged | Ready to test |
| 5 | Batch pickup | One signing session; separate certificate per order | Ready to test |
| 6 | Staff override | Logged with staff name; no ID photo required | Ready to test |
| 7 | POS release | Colour status, signature beside ID, staff login recorded, order fulfilled | Ready to test |
| 8 | Certificate & notifications | PDF with frozen items + hashes + signature; emailed; SMS confirmation | Ready to test |
| 9 | 48-hour inspection window | Deadline shown; report appends to audit; auto-close if no report | Ready to test |
| 10 | Reissue / expiry | Old token revoked; 14-day expiry enforced | Ready to test |

## Sample audit record (after successful submit)
```json
{
  "order_number": "TEST-1001",
  "buyer_name": "Alex Rivera",
  "pickup_person_name": "Alex Rivera",
  "pickup_person_role": "self",
  "consent_version": "v1.0-2026-10-26",
  "submitted_at": "2026-10-27T04:30:00-04:00",
  "ip_address": "203.0.113.42",
  "delivery_channel": "sms",
  "aircall_delivery_status": "delivered",
  "signature_sha256": "a1b2c3...",
  "id_photo_sha256": "d4e5f6...",
  "staff_override": false
}
```

## Sample order note
`Pickup verified — signed by Alex Rivera, 2026-10-27 04:30 America/Toronto. ID on file.`

## Sample tag
`pickup-verified`

## Next actions for you
1. Follow `docs/DEPLOYMENT.md` to create the Shopify app and deploy to Vercel.
2. Install on the development store only.
3. Create a test LOCAL PICKUP order and run the flow.
4. Send me screenshots of any issues; I will iterate.

**Nothing has touched a live customer order.**
