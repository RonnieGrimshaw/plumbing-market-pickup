# Pickup Certificate PDF — Specification

One-page PDF generated on successful submission.

## Layout
- Header: Plumbing Market logo + “Pickup Certificate”
- Order number, date/time (America/Toronto)
- Buyer name
- Pickup person name + role
- Frozen item list with quantities (exact snapshot at signing time)
- Consent version + acceptance timestamp
- Submission timestamp, IP address
- SHA-256 of signature image
- SHA-256 of ID photo
- Embedded signature image
- Inspection deadline (pickup time + 48 hours)
- Footer: “Retained 3 years for fraud prevention. Legal hold may apply.”

## Storage
- Uploaded to Shopify Files
- Attached as order metafield `pickup.certificate_file`
- Emailed to buyer from info@plumbingmarket.ca
- Available via “Download evidence” (owner role only)

## Generation
Use a library such as PDFKit or Puppeteer on the backend. Template variables come from the audit record + order line items.
